﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp1
{
   

        public partial class Form1 : Form
        {
            private const string FILENAME = "r1.txt";
            private Queue<string> highGradesQueue = new Queue<string>();
            private Queue<string> lowGradesQueue = new Queue<string>();

            public Form1()
            {
                InitializeComponent();
            }

            private void Form1_Load(object sender, EventArgs e)
            {
                string[] lines = ReadFromFile(FILENAME);
                if (lines == null)
                {
                    MessageBox.Show($"Файл {FILENAME} не найден или пустой.");
                    return;
                }

                foreach (string line in lines)
                {
                    string[] parts = line.Split(';');
                    if (parts.Length != 7)
                    {
                        MessageBox.Show($"Ошибка в строке файла: {line}");
                        continue;
                    }

                    int[] grades = parts.Skip(3).Select(int.Parse).ToArray();
                    if (grades.All(g => g >= 4))
                    {
                        highGradesQueue.Enqueue(line);
                    }
                    else
                    {
                        lowGradesQueue.Enqueue(line);
                    }
                }

                PrintData();
            }

            private void PrintData()
            {
               richTextBox1.Clear();

                foreach (string line in highGradesQueue.Concat(lowGradesQueue))
                {
                    richTextBox1.AppendText(line + Environment.NewLine);
                }
            }

            private string[] ReadFromFile(string filename)
            {
                try
                {
                    return File.ReadAllLines(filename);
                }
                catch (Exception e)
                {
                    MessageBox.Show($"Ошибка чтения файла {filename}: {e.Message}");
                    return null;
                }
            }
        }
    }